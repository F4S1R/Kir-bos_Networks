import os

print("Installation de Kirébos Networks (Cloud)")

email = input("Entrez votre email: ")
phone = input("Entrez votre numéro de téléphone: ")

print("Installation des dépendances pour Cloud...")
# Commandes d'installation
print(f"Installation terminée. Notifications activées pour {email}.")
